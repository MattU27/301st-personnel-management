// Export AFP Personnel Database to JSON files
// Run with: node src/scripts/exportPersonnelDB.js

const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');

// Connect to the afp_personnel_db database specifically
const MONGODB_URI = "mongodb://localhost:27017/afp_personnel_db";

// Output directory in the user's Downloads folder
const OUTPUT_DIR = path.join(process.env.USERPROFILE || process.env.HOME, 'Downloads', 'afp_personnel_backup');

console.log('Starting AFP Personnel database export...');
console.log(`Attempting to connect to: ${MONGODB_URI}`);

// Create output directory if it doesn't exist
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  console.log(`Created output directory: ${OUTPUT_DIR}`);
}

// Connect to the database
mongoose.connect(MONGODB_URI)
  .then(async () => {
    console.log('Connected to MongoDB successfully');
    console.log(`Database name: ${mongoose.connection.db.databaseName}`);
    
    try {
      // Get all collections in the database
      const collections = await mongoose.connection.db.listCollections().toArray();
      console.log(`Found ${collections.length} collections`);
      
      if (collections.length === 0) {
        console.log('No collections found in afp_personnel_db. This database appears to be empty.');
        return;
      }
      
      // Export each collection
      for (const collection of collections) {
        const collectionName = collection.name;
        console.log(`Exporting collection: ${collectionName}`);
        
        // Get all documents in the collection
        const documents = await mongoose.connection.db.collection(collectionName).find({}).toArray();
        
        // Save to JSON file
        const outputPath = path.join(OUTPUT_DIR, `${collectionName}.json`);
        fs.writeFileSync(outputPath, JSON.stringify(documents, null, 2));
        
        console.log(`- Exported ${documents.length} documents to ${outputPath}`);
      }
      
      console.log('\nExport completed successfully!');
      console.log(`All data exported to: ${OUTPUT_DIR}`);
      console.log(`\nYou can find your exported database in the Downloads folder.`);
      console.log(`Path: ${OUTPUT_DIR}`);
      
      // Create a README file with instructions
      const readmePath = path.join(OUTPUT_DIR, 'README.txt');
      const readmeContent = `AFP PERSONNEL DATABASE BACKUP
===============================
Created: ${new Date().toLocaleString()}

This folder contains a backup of your AFP Personnel Management System database.
Each JSON file represents a collection from your MongoDB database.

To import this data into another MongoDB instance:
1. Install MongoDB Database Tools (https://www.mongodb.com/try/download/database-tools)
2. Use the 'mongoimport' tool for each file:
   mongoimport --db afp_personnel_db --collection [COLLECTION_NAME] --file [FILENAME] --jsonArray

For example:
   mongoimport --db afp_personnel_db --collection users --file users.json --jsonArray

Note: Replace [COLLECTION_NAME] with the name of the collection (e.g., users, documents, trainings)
      Replace [FILENAME] with the corresponding JSON file path.
`;
      fs.writeFileSync(readmePath, readmeContent);
      console.log('Created README.txt with import instructions');
      
    } catch (error) {
      console.error('Error exporting data:', error);
    } finally {
      // Close the connection
      await mongoose.connection.close();
      console.log('Database connection closed');
    }
  })
  .catch(error => {
    console.error('Failed to connect to MongoDB:', error);
    console.log('\nTroubleshooting tips:');
    console.log('1. Make sure MongoDB is running locally on port 27017');
    console.log('2. Check if the afp_personnel_db database exists on your MongoDB server');
  }); 