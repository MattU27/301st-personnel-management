// Export MongoDB database to JSON files without requiring .env
// Run with: node src/scripts/exportLocalDatabase.js

const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');

// Direct connection to local MongoDB - no .env file needed
const MONGODB_URI = "mongodb://localhost:27017/afp";

// Output directory in the user's Downloads folder
const OUTPUT_DIR = path.join(process.env.USERPROFILE || process.env.HOME, 'Downloads', 'afp_database_backup');

console.log('Starting database export...');
console.log(`Attempting to connect to: ${MONGODB_URI}`);

// Create output directory if it doesn't exist
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  console.log(`Created output directory: ${OUTPUT_DIR}`);
}

// Connect to the database
mongoose.connect(MONGODB_URI)
  .then(async () => {
    console.log('Connected to MongoDB successfully');
    console.log(`Database name: ${mongoose.connection.db.databaseName}`);
    
    try {
      // Get all collections in the database
      const collections = await mongoose.connection.db.listCollections().toArray();
      console.log(`Found ${collections.length} collections`);
      
      if (collections.length === 0) {
        console.log('No collections found. This could mean:');
        console.log('1. The database exists but is empty');
        console.log('2. You might be connecting to the wrong database');
        
        // Try to list all available databases
        try {
          const dbs = await mongoose.connection.db.admin().listDatabases();
          console.log('\nAvailable databases:');
          dbs.databases.forEach(db => {
            console.log(`- ${db.name}`);
          });
        } catch (err) {
          console.log('Could not list all databases. You might not have admin privileges.');
        }
        
        return;
      }
      
      // Export each collection
      for (const collection of collections) {
        const collectionName = collection.name;
        console.log(`Exporting collection: ${collectionName}`);
        
        // Get all documents in the collection
        const documents = await mongoose.connection.db.collection(collectionName).find({}).toArray();
        
        // Save to JSON file
        const outputPath = path.join(OUTPUT_DIR, `${collectionName}.json`);
        fs.writeFileSync(outputPath, JSON.stringify(documents, null, 2));
        
        console.log(`- Exported ${documents.length} documents to ${outputPath}`);
      }
      
      console.log('\nExport completed successfully!');
      console.log(`All data exported to: ${OUTPUT_DIR}`);
      console.log(`\nYou can find your exported database in the Downloads folder.`);
    } catch (error) {
      console.error('Error exporting data:', error);
    } finally {
      // Close the connection
      await mongoose.connection.close();
      console.log('Database connection closed');
    }
  })
  .catch(error => {
    console.error('Failed to connect to MongoDB:', error);
    console.log('\nTroubleshooting tips:');
    console.log('1. Make sure MongoDB is running locally on port 27017');
    console.log('2. Try changing the database name in the script if "afp" is not correct');
  }); 