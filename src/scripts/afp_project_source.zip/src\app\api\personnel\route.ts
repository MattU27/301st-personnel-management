import { NextResponse } from 'next/server';
import { dbConnect } from '@/utils/dbConnect';
import Personnel from '@/models/Personnel';

// Simple in-memory rate limiter
const searches = new Map<string, { count: number, timestamp: number }>();
const RATE_LIMIT_WINDOW = 5000; // 5 seconds
const RATE_LIMIT_MAX = 10; // 10 requests per 5 seconds

/**
 * GET handler to retrieve personnel data
 */
export async function GET(request: Request) {
  try {
    // Get client IP for rate limiting
    const ip = request.headers.get('x-forwarded-for') || 'unknown';
    
    // Rate limiting
    const now = Date.now();
    const userSearches = searches.get(ip) || { count: 0, timestamp: now };
    
    // Reset counter if window expired
    if (now - userSearches.timestamp > RATE_LIMIT_WINDOW) {
      userSearches.count = 0;
      userSearches.timestamp = now;
    }
    
    // Increment count
    userSearches.count++;
    searches.set(ip, userSearches);
    
    // Check rate limit
    if (userSearches.count > RATE_LIMIT_MAX) {
      return NextResponse.json(
        { success: false, error: 'Too many requests. Please try again later.' },
        { status: 429 }
      );
    }

    // Connect to MongoDB
    await dbConnect();
    
    // Get query parameters
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');
    const company = searchParams.get('company');
    const status = searchParams.get('status');
    const pageSize = searchParams.get('pageSize') ? parseInt(searchParams.get('pageSize')!) : 10;
    const page = searchParams.get('page') ? parseInt(searchParams.get('page')!) : 1;
    
    // Build query
    const query: any = {};
    if (company) query.company = company;
    if (status) query.status = status;
    
    // Add search functionality
    if (search && search.trim() !== '') {
      // Create a more flexible search query
      const searchRegex = new RegExp(search.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&'), 'i');
      query.$or = [
        { name: { $regex: searchRegex } },
        { rank: { $regex: searchRegex } },
        { email: { $regex: searchRegex } },
        { serviceNumber: { $regex: searchRegex } },
      ];
    }
    
    // Execute query with optimized options
    const skip = (page - 1) * pageSize;
    const personnel = await Personnel.find(query, {}, { lean: true })
      .skip(skip)
      .limit(pageSize)
      .sort({ lastUpdated: -1 });
    
    // Get total count for pagination
    const total = await Personnel.countDocuments(query);
    const totalPages = Math.ceil(total / pageSize);
    
    // Create response with cache control to prevent browser caching
    const response = NextResponse.json({
      success: true,
      data: {
        personnel,
        totalPages,
        pagination: {
          total,
          page,
          pageSize,
          pages: totalPages,
        },
      },
    });
    
    // Set cache control headers to prevent browser caching
    response.headers.set('Cache-Control', 'no-store, max-age=0');
    
    return response;
  } catch (error: any) {
    console.error('Error fetching personnel:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Error fetching personnel' },
      { status: 500 }
    );
  }
}

/**
 * POST handler to create a new personnel record
 */
export async function POST(request: Request) {
  try {
    // Connect to MongoDB
    await dbConnect();
    
    // Get data from request body
    const data = await request.json();
    
    // Validate required fields
    if (!data.name || !data.rank || !data.company || !data.email) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    // Create new personnel
    const newPersonnel = {
      ...data,
      lastUpdated: new Date(),
      serviceNumber: data.serviceNumber || `SN-${Math.floor(100000 + Math.random() * 900000)}`,
      status: data.status || 'active',
      role: 'staff' // Always set role to staff by default
    };
    
    // Save to database
    const result = await Personnel.create(newPersonnel);
    
    return NextResponse.json({
      success: true,
      data: {
        personnel: {
          ...result.toObject(),
          id: result._id
        }
      }
    });
  } catch (error: any) {
    console.error('Error creating personnel:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Error creating personnel' },
      { status: 500 }
    );
  }
}

/**
 * DELETE handler to remove a personnel record
 */
export async function DELETE(request: Request) {
  try {
    // Connect to MongoDB
    await dbConnect();
    
    // Get the ID from the URL
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json(
        { success: false, error: 'Personnel ID is required' },
        { status: 400 }
      );
    }
    
    // Find and delete the personnel
    const result = await Personnel.findByIdAndDelete(id);
    
    if (!result) {
      return NextResponse.json(
        { success: false, error: 'Personnel not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({
      success: true,
      message: 'Personnel deleted successfully'
    });
  } catch (error: any) {
    console.error('Error deleting personnel:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Error deleting personnel' },
      { status: 500 }
    );
  }
} 