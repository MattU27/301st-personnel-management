'use client';

import { useState } from 'react';
import { Document as DocumentType, DocumentVersion } from '@/types/personnel';
import { 
  DocumentTextIcon, 
  ArrowDownTrayIcon, 
  ClockIcon, 
  UserIcon, 
  ShieldCheckIcon,
  DocumentDuplicateIcon,
  ArrowUpTrayIcon,
  XMarkIcon,
  ExclamationCircleIcon,
  CheckCircleIcon
} from '@heroicons/react/24/outline';
import Button from './Button';
import DocumentVersionHistory from './DocumentVersionHistory';
import ConfirmationDialog from './ConfirmationDialog';

type DocumentStatus = 'verified' | 'pending' | 'rejected';
type SecurityClassification = 'Unclassified' | 'Confidential' | 'Secret' | 'Top Secret';

interface Document {
  _id: string;
  name: string;
  type: string;
  uploadDate: string;
  status: DocumentStatus;
  verifiedBy?: string;
  verifiedDate?: string;
  comments?: string;
  fileUrl: string;
  securityClassification: SecurityClassification;
  expirationDate?: string;
}

interface DocumentViewerProps {
  document: Document;
  onClose: () => void;
}

export default function DocumentViewer({ document, onClose }: DocumentViewerProps) {
  const [showInfo, setShowInfo] = useState(true);

  const handleDownload = () => {
    // In a real implementation, this would trigger a download of the actual file
    window.open(document.fileUrl, '_blank');
  };

  const getStatusBadge = (status: DocumentStatus) => {
    switch (status) {
      case 'verified':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircleIcon className="h-4 w-4 mr-1" />
            Verified
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <ClockIcon className="h-4 w-4 mr-1" />
            Pending
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <ExclamationCircleIcon className="h-4 w-4 mr-1" />
            Rejected
          </span>
        );
    }
  };

  const getFileType = (filename: string) => {
    const extension = filename.split('.').pop()?.toLowerCase();
    if (!extension) return 'unknown';
    
    if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'].includes(extension)) {
      return 'image';
    } else if (['pdf'].includes(extension)) {
      return 'pdf';
    } else if (['doc', 'docx'].includes(extension)) {
      return 'word';
    } else if (['xls', 'xlsx'].includes(extension)) {
      return 'excel';
    } else if (['ppt', 'pptx'].includes(extension)) {
      return 'powerpoint';
    } else {
      return 'unknown';
    }
  };

  const fileType = getFileType(document.name);
  const isPreviewable = ['image', 'pdf'].includes(fileType);
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] flex flex-col animate-fade-in-up">
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center">
            <DocumentTextIcon className="h-6 w-6 text-indigo-600 mr-2" />
            <h2 className="document-title truncate max-w-2xl">
              {document.name}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500 focus:outline-none"
          >
            <XMarkIcon className="h-6 w-6" />
          </button>
        </div>
        
        <div className="flex-1 overflow-auto flex divide-x divide-gray-200">
          {/* Document preview pane */}
          <div className={`${showInfo ? 'w-3/4' : 'w-full'} h-full bg-gray-100 document-preview-container flex items-center justify-center p-4 relative`}>
            {isPreviewable ? (
              fileType === 'image' ? (
                <img 
                  src={document.fileUrl} 
                  alt={document.name} 
                  className="max-w-full max-h-[75vh] object-contain"
                />
              ) : (
                <iframe 
                  src={document.fileUrl} 
                  className="w-full h-[75vh] border-0"
                  title={document.name}
                />
              )
            ) : (
              <div className="text-center p-10">
                <div className="bg-indigo-100 mx-auto rounded-full p-3 h-20 w-20 flex items-center justify-center mb-4">
                  <DocumentTextIcon className="h-10 w-10 text-indigo-600" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">
                  {document.name}
                </h3>
                <p className="text-sm text-gray-500 mb-6">
                  This file type cannot be previewed
                </p>
                <Button
                  variant="primary"
                  onClick={handleDownload}
                  className="flex items-center mx-auto download-button"
                >
                  <ArrowDownTrayIcon className="h-5 w-5 mr-2" />
                  Download File
                </Button>
              </div>
            )}
            
            <button 
              className="absolute top-2 right-2 bg-white rounded-full p-1 shadow hover:bg-gray-100"
              onClick={() => setShowInfo(!showInfo)}
              title={showInfo ? "Hide details" : "Show details"}
            >
              {showInfo ? <XMarkIcon className="h-5 w-5" /> : <DocumentDuplicateIcon className="h-5 w-5" />}
            </button>
          </div>
          
          {/* Document info pane */}
          {showInfo && (
            <div className="w-1/4 h-full overflow-y-auto p-4 document-info-panel">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Document Information</h3>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="text-gray-500">Status</div>
                      <div>{getStatusBadge(document.status)}</div>
                      
                      <div className="text-gray-500">Type</div>
                      <div className="font-medium text-gray-900">{document.type}</div>
                      
                      <div className="text-gray-500">Upload Date</div>
                      <div className="font-medium text-gray-900">{document.uploadDate}</div>
                      
                      <div className="text-gray-500">Security</div>
                      <div className="font-medium text-gray-900">{document.securityClassification}</div>
                      
                      {document.expirationDate && (
                        <>
                          <div className="text-gray-500">Expiration</div>
                          <div className="font-medium text-gray-900">{document.expirationDate}</div>
                        </>
                      )}
                      
                      {document.verifiedBy && (
                        <>
                          <div className="text-gray-500">Verified By</div>
                          <div className="font-medium text-gray-900">{document.verifiedBy}</div>
                        </>
                      )}
                      
                      {document.verifiedDate && (
                        <>
                          <div className="text-gray-500">Verified Date</div>
                          <div className="font-medium text-gray-900">{document.verifiedDate}</div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                
                {document.comments && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-1">Comments</h4>
                    <div className="bg-red-50 text-red-700 p-3 rounded-md text-sm">
                      {document.comments}
                    </div>
                  </div>
                )}
                
                <div className="pt-4">
                  <Button
                    variant="primary"
                    onClick={handleDownload}
                    className="w-full flex items-center justify-center download-button"
                  >
                    <ArrowDownTrayIcon className="h-5 w-5 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
} 