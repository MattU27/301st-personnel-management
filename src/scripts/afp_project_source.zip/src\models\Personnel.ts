import mongoose, { Schema } from 'mongoose';
import { UserRole, PersonnelStatus } from '@/types/personnel';

export enum CompanyType {
  ALPHA = 'Alpha',
  BRAVO = 'Bravo',
  CHARLIE = 'Charlie',
  DELTA = 'Delta',
  HEADQUARTERS = 'Headquarters',
  NERRSC = 'NERRSC (NERR-Signal Company)',
  NERFAB = 'NERFAB (NERR-Field Artillery Battery)'
}

// Define the Personnel document interface
export interface IPersonnel extends mongoose.Document {
  name: string;
  rank: string;
  company: string;
  status: PersonnelStatus;
  lastUpdated: Date;
  email: string;
  phoneNumber?: string;
  dateJoined: Date;
  role: UserRole;
  serviceNumber: string;
  address?: {
    street?: string;
    city?: string;
    province?: string;
    postalCode?: string;
  };
  specialization?: string[];
  emergencyContact?: {
    name?: string;
    relationship?: string;
    contactNumber?: string;
  };
  trainings?: Array<{
    title: string;
    date: Date;
    status: string;
    verifiedBy?: string;
  }>;
  documents?: Array<{
    title: string;
    type: string;
    uploadDate: Date;
    status: string;
    verifiedBy?: string;
    url: string;
  }>;
  createdAt: Date;
  updatedAt: Date;
}

// Define the Personnel schema
const PersonnelSchema = new Schema<IPersonnel>({
  name: {
    type: String,
    required: [true, 'Please provide a name'],
    trim: true,
  },
  rank: {
    type: String,
    required: [true, 'Please provide a rank'],
    trim: true,
  },
  company: {
    type: String,
    required: [true, 'Please provide a company'],
    enum: Object.values(CompanyType),
    default: CompanyType.ALPHA,
  },
  status: {
    type: String,
    enum: ['active', 'pending', 'inactive', 'retired', 'standby', 'ready'],
    default: 'pending',
  },
  lastUpdated: {
    type: Date,
    default: Date.now,
  },
  email: {
    type: String,
    required: [true, 'Please provide an email'],
    unique: true,
    trim: true,
    lowercase: true,
  },
  phoneNumber: {
    type: String,
    trim: true,
  },
  dateJoined: {
    type: Date,
    default: Date.now,
  },
  role: {
    type: String,
    enum: ['reservist', 'enlisted', 'staff', 'admin', 'director'],
    default: 'reservist',
  },
  serviceNumber: {
    type: String,
    required: [true, 'Please provide service number'],
    unique: true,
    trim: true,
  },
  address: {
    street: String,
    city: String,
    province: String,
    postalCode: String,
  },
  specialization: [{
    type: String,
  }],
  emergencyContact: {
    name: String,
    relationship: String,
    contactNumber: String,
  },
  trainings: [{
    title: String,
    date: Date,
    status: {
      type: String,
      enum: ['Completed', 'Pending', 'Missed'],
      default: 'Pending'
    },
    verifiedBy: String
  }],
  documents: [{
    title: String,
    type: String,
    uploadDate: {
      type: Date,
      default: Date.now
    },
    status: String,
    verifiedBy: String,
    url: String
  }],
}, {
  timestamps: true,
});

// Create and export the Personnel model
export default mongoose.models.Personnel || mongoose.model<IPersonnel>('Personnel', PersonnelSchema, 'personnels'); 