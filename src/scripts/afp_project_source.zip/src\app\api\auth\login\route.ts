import { NextResponse } from 'next/server';
import { dbConnect } from '@/utils/dbConnect';
import User from '@/models/User';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

// JWT secret key - in production, this should be an environment variable
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-for-jwt-signing';

export async function POST(request: Request) {
  try {
    // Connect to MongoDB
    await dbConnect();
    
    // Get login credentials from request body
    const { email, password } = await request.json();
    
    console.log(`Login attempt for: ${email}`);
    
    // Validate email and password
    if (!email || !password) {
      console.log('Missing email or password');
      return NextResponse.json(
        { success: false, error: 'Email and password are required' },
        { status: 400 }
      );
    }
    
    // Find user with email
    const user = await User.findOne({ email }).select('+password');
    
    // Check if user exists
    if (!user) {
      console.log(`User not found: ${email}`);
      return NextResponse.json(
        { success: false, error: 'Invalid credentials' },
        { status: 401 }
      );
    }
    
    console.log(`User found: ${email}`);
    console.log(`Password from DB: ${user.password}`);
    console.log(`Password from request: ${password}`);
    
    // Try multiple methods to ensure password comparison works
    const directCompare = await bcrypt.compare(password, user.password);
    const modelCompare = await user.comparePassword(password);
    
    console.log(`Direct bcrypt compare result: ${directCompare}`);
    console.log(`Model comparePassword result: ${modelCompare}`);
    
    // Use direct bcrypt comparison for validation
    const isPasswordValid = directCompare;
    
    if (!isPasswordValid) {
      console.log(`Invalid password for user: ${email}`);
      return NextResponse.json(
        { success: false, error: 'Invalid credentials' },
        { status: 401 }
      );
    }
    
    // Update last login time
    user.lastLogin = new Date();
    await user.save();
    
    // Create user object without password
    const userWithoutPassword = {
      _id: user._id,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      role: user.role,
      status: user.status,
      rank: user.rank,
      company: user.company,
      profileImage: user.profileImage,
    };
    
    // Create JWT token
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      JWT_SECRET,
      { expiresIn: '1d' }
    );
    
    console.log(`Login successful for user: ${email}, role: ${user.role}`);
    
    // Return success response with token and user data
    return NextResponse.json({
      success: true,
      message: 'Login successful',
      data: {
        token,
        user: userWithoutPassword,
      },
    });
  } catch (error: any) {
    console.error('Login error:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Login failed' },
      { status: 500 }
    );
  }
} 