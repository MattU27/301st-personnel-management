import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

// Define user roles
export enum UserRole {
  RESERVIST = 'reservist',
  ENLISTED = 'enlisted',
  STAFF = 'staff',
  ADMIN = 'admin',
  DIRECTOR = 'director',
}

// Define user status
export enum UserStatus {
  ACTIVE = 'active',
  PENDING = 'pending',
  INACTIVE = 'inactive',
  RETIRED = 'retired',
  STANDBY = 'standby',
  READY = 'ready',
}

// Define military ranks
export enum MilitaryRank {
  // Enlisted Ranks
  PRIVATE = 'Private',
  PFC = 'Private First Class',
  CORPORAL = 'Corporal',
  SERGEANT = 'Sergeant',
  
  // Officer Ranks
  SECOND_LIEUTENANT = 'Second Lieutenant',
  FIRST_LIEUTENANT = 'First Lieutenant',
  CAPTAIN = 'Captain',
  MAJOR = 'Major',
  LIEUTENANT_COLONEL = 'Lieutenant Colonel',
  COLONEL = 'Colonel',
  BRIGADIER_GENERAL = 'Brigadier General',
  MAJOR_GENERAL = 'Major General',
  LIEUTENANT_GENERAL = 'Lieutenant General',
  GENERAL = 'General',
}

// Define companies
export enum Company {
  ALPHA = 'Alpha',
  BRAVO = 'Bravo',
  CHARLIE = 'Charlie',
  HQ = 'Headquarters',
  NERRSC = 'NERRSC (NERR-Signal Company)',
  NERRFAB = 'NERRFAB (NERR-Field Artillery Battery)',
}

// Define the user document interface
export interface IUser extends mongoose.Document {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  role: UserRole;
  status: UserStatus;
  rank?: MilitaryRank;
  company?: Company;
  militaryId: string;
  contactNumber?: string;
  dateOfBirth?: Date;
  address?: {
    street?: string;
    city?: string;
    province?: string;
    postalCode?: string;
  };
  emergencyContact?: {
    name?: string;
    relationship?: string;
    contactNumber?: string;
  };
  profileImage?: string;
  specializations?: string[];
  lastLogin?: Date;
  createdAt: Date;
  updatedAt: Date;
  comparePassword(candidatePassword: string): Promise<boolean>;
  getFullName(): string;
}

// Define the User schema
const UserSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: [true, 'Please provide your first name'],
    trim: true,
  },
  lastName: {
    type: String,
    required: [true, 'Please provide your last name'],
    trim: true,
  },
  email: {
    type: String,
    required: [true, 'Please provide your email'],
    unique: true,
    trim: true,
    lowercase: true,
    match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email address'],
  },
  password: {
    type: String,
    required: [true, 'Please provide a password'],
    minlength: [8, 'Password should be at least 8 characters long'],
    select: false, // Don't return password in queries by default
  },
  militaryId: {
    type: String,
    required: [true, 'Please provide your military ID'],
    trim: true,
  },
  role: {
    type: String,
    enum: Object.values(UserRole),
    default: UserRole.STAFF,
  },
  status: {
    type: String,
    enum: Object.values(UserStatus),
    default: UserStatus.PENDING,
  },
  rank: {
    type: String,
    enum: Object.values(MilitaryRank),
    required: false,
  },
  company: {
    type: String,
    enum: Object.values(Company),
    required: false,
  },
  contactNumber: {
    type: String,
    trim: true,
  },
  dateOfBirth: {
    type: Date,
  },
  address: {
    street: String,
    city: String,
    province: String,
    postalCode: String,
  },
  emergencyContact: {
    name: String,
    relationship: String,
    contactNumber: String,
  },
  profileImage: {
    type: String,
  },
  specializations: [{
    type: String,
  }],
  lastLogin: {
    type: Date,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
}, {
  timestamps: true,
});

// Pre-save hook to hash password
UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) {
    return next();
  }
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error: any) {
    next(error);
  }
});

// Method to compare password
UserSchema.methods.comparePassword = async function(candidatePassword: string): Promise<boolean> {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    throw error;
  }
};

// Method to get full name
UserSchema.methods.getFullName = function(): string {
  return `${this.firstName} ${this.lastName}`;
};

// Create and export the User model
export default mongoose.models.User || mongoose.model<IUser>('User', UserSchema); 