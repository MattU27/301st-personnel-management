'use client';

import { useState, useEffect, useMemo, useRef } from 'react';
import { 
  UserGroupIcon, 
  MagnifyingGlassIcon, 
  FunnelIcon,
  PencilSquareIcon,
  TrashIcon,
  EyeIcon,
  UserPlusIcon,
  CheckCircleIcon,
  XCircleIcon
} from '@heroicons/react/24/outline';
import Card from '@/components/Card';
import Button from '@/components/Button';
import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import PersonnelModal from '@/components/PersonnelModal';
import { Personnel, PersonnelStatus, CompanyType } from '@/types/personnel';
import ConfirmationDialog from '@/components/ConfirmationDialog';
import PermissionGuard from '@/components/PermissionGuard';
import { useRouter } from 'next/navigation';

const COMPANIES: CompanyType[] = ['Alpha', 'Bravo', 'Charlie', 'Headquarters', 'NERRSC (NERR-Signal Company)', 'NERRFAB (NERR-Field Artillery Battery)'];
const STATUS_OPTIONS: PersonnelStatus[] = ['ready', 'standby', 'retired'];

const ITEMS_PER_PAGE = 10;

// Toast notification component
interface ToastProps {
  message: string;
  type: 'success' | 'error';
  onClose: () => void;
}

const Toast = ({ message, type, onClose }: ToastProps) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
    
    return () => clearTimeout(timer);
  }, [onClose]);
  
  return (
    <div className="fixed bottom-4 right-4 z-50 animate-fade-in-up">
      <div className={`flex items-center p-4 rounded-lg shadow-lg ${
        type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
      }`}>
        {type === 'success' ? (
          <CheckCircleIcon className="h-5 w-5 mr-2" />
        ) : (
          <XCircleIcon className="h-5 w-5 mr-2" />
        )}
        <span>{message}</span>
        <button 
          onClick={onClose}
          className="ml-4 text-gray-500 hover:text-gray-700"
        >
          <XCircleIcon className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

// SearchInput component separated for better focus management
const SearchInput = ({ value, onChange }: { value: string, onChange: (value: string) => void }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Handle change with direct value manipulation
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault(); // Prevent default behavior
    e.stopPropagation(); // Stop event propagation
    onChange(e.target.value);
  };

  // Focus input on mount
  useEffect(() => {
    if (inputRef.current) {
      // Focus the input element when component mounts
      setTimeout(() => {
        if (inputRef.current) {
          inputRef.current.focus();
        }
      }, 100);
    }
  }, []);

  return (
    <div className="relative">
      <input
        ref={inputRef}
        type="text"
        placeholder="Search by name, rank, email, service #"
        className="pl-10 pr-4 py-2 border rounded-lg w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
        value={value}
        onChange={handleChange}
        autoComplete="off"
        spellCheck="false"
        style={{ caretColor: 'auto' }}
      />
      <MagnifyingGlassIcon className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
    </div>
  );
};

// FilterDropdown component for consistent styling
const FilterDropdown = ({ 
  value, 
  onChange, 
  options, 
  label 
}: { 
  value: string, 
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, 
  options: {value: string, label: string}[],
  label: string
}) => {
  return (
    <div className="relative">
      <select
        className="pl-3 pr-8 py-2 border rounded-lg appearance-none w-full md:w-auto focus:outline-none focus:ring-2 focus:ring-blue-500"
        value={value}
        onChange={onChange}
        aria-label={label}
      >
        {options.map(option => (
          <option key={option.value} value={option.value}>{option.label}</option>
        ))}
      </select>
      <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
        <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
          <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
        </svg>
      </div>
    </div>
  );
};

export default function PersonnelPage() {
  const { user, hasPermission, hasSpecificPermission } = useAuth();
  const router = useRouter();
  const [allPersonnel, setAllPersonnel] = useState<Personnel[]>([]);
  const [filteredPersonnel, setFilteredPersonnel] = useState<Personnel[]>([]);
  
  // Create separate state variables for input and filters
  const [searchValue, setSearchValue] = useState("");
  const [filterStatus, setFilterStatus] = useState<PersonnelStatus | 'All'>('All');
  const [filterCompany, setFilterCompany] = useState<CompanyType | 'All'>('All');
  
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedPersonnel, setSelectedPersonnel] = useState<Personnel | null>(null);
  const [modalMode, setModalMode] = useState<'view' | 'edit'>('view');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleteConfirmationOpen, setIsDeleteConfirmationOpen] = useState(false);
  const [personnelToDelete, setPersonnelToDelete] = useState<Personnel | null>(null);
  const [totalPages, setTotalPages] = useState(1);
  const [initialLoadComplete, setInitialLoadComplete] = useState(false);
  
  // Toast notification state
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // Track recently modified personnel for animations
  const [recentlyModified, setRecentlyModified] = useState<string | null>(null);
  
  // Clear highlight after animation completes
  useEffect(() => {
    if (recentlyModified) {
      const timer = setTimeout(() => {
        setRecentlyModified(null);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [recentlyModified]);

  // Check if user has permission to view personnel
  const hasViewPermission = hasSpecificPermission('view_company_personnel') || 
                           hasSpecificPermission('view_all_personnel');

  // Load all personnel data once
  useEffect(() => {
    const fetchAllPersonnel = async () => {
      setIsLoading(true);
      try {
        // Only fetch once at the beginning
        const response = await fetch(`/api/personnel?pageSize=100`);
        
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        
        if (data.success) {
          // Process the data
          let personnelData = data.data.personnel || [];
          
          // Map MongoDB _id to id for frontend compatibility
          personnelData = personnelData.map((person: any) => ({
            ...person,
            id: person._id || person.id,
            lastUpdated: person.lastUpdated ? new Date(person.lastUpdated).toLocaleDateString() : new Date().toLocaleDateString()
          }));
          
          setAllPersonnel(personnelData);
          setFilteredPersonnel(personnelData);
          
          // Set pagination data
          const totalPagesCount = Math.ceil(personnelData.length / ITEMS_PER_PAGE);
          setTotalPages(totalPagesCount);
          setInitialLoadComplete(true);
        } else {
          throw new Error(data.error || 'Failed to fetch personnel');
        }
      } catch (error) {
        console.error('Failed to fetch personnel:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAllPersonnel();
  }, []);

  // Client-side filtering effect
  useEffect(() => {
    if (!initialLoadComplete) return;
    
    // Filter personnel
    const filtered = allPersonnel.filter(person => {
      // Search filter
      const searchTerm = searchValue.toLowerCase();
      const searchMatch = searchValue === '' || 
        (person.name?.toLowerCase().includes(searchTerm)) ||
        (person.rank?.toLowerCase().includes(searchTerm)) ||
        (person.email?.toLowerCase().includes(searchTerm)) ||
        (typeof person.serviceNumber === 'string' && person.serviceNumber.toLowerCase().includes(searchTerm));
      
      // Company & status filters
      const companyMatch = filterCompany === 'All' || person.company === filterCompany;
      const statusMatch = filterStatus === 'All' || person.status === filterStatus;
      
      return searchMatch && companyMatch && statusMatch;
    });
    
    setFilteredPersonnel(filtered);
    setTotalPages(Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE)));
    
    // Reset to first page when filters change
    setCurrentPage(1);
  }, [searchValue, filterCompany, filterStatus, allPersonnel, initialLoadComplete]);

  // Handle search input change separately to avoid rendering issues
  const handleSearchChange = (value: string) => {
    setSearchValue(value);
  };

  // Get current page data
  const currentPersonnel = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    return filteredPersonnel.slice(startIndex, endIndex);
  }, [filteredPersonnel, currentPage]);

  // Company filter options
  const companyOptions = [
    { value: 'All', label: 'All Companies' },
    { value: 'Alpha', label: 'Alpha' },
    { value: 'Bravo', label: 'Bravo' },
    { value: 'Charlie', label: 'Charlie' },
    { value: 'Delta', label: 'Delta' },
    { value: 'Headquarters', label: 'Headquarters' },
    { value: 'NERFAB', label: 'NERFAB' }
  ];

  // Status filter options
  const statusOptions = [
    { value: 'All', label: 'All Status' },
    { value: 'active', label: 'Active' },
    { value: 'standby', label: 'Standby' },
    { value: 'leave', label: 'Leave' },
    { value: 'ready', label: 'Ready' },
    { value: 'deployed', label: 'Deployed' }
  ];

  // Modal handlers
  const handleView = (person: Personnel) => {
    setSelectedPersonnel(person);
    setModalMode('view');
    setIsModalOpen(true);
  };

  const handleEdit = (person: Personnel) => {
    setSelectedPersonnel(person);
    setModalMode('edit');
    setIsModalOpen(true);
  };

  const handleDeleteClick = (person: Personnel) => {
    setPersonnelToDelete(person);
    setIsDeleteConfirmationOpen(true);
  };

  const handleDelete = async () => {
    if (!personnelToDelete) return;
    
    try {
      // Make API call to delete the personnel
      const response = await fetch(`/api/personnel?id=${personnelToDelete.id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to delete personnel');
      }
      
      // Remove from local state
      setFilteredPersonnel(prev => prev.filter(p => p.id !== personnelToDelete.id));
      setAllPersonnel(prev => prev.filter(p => p.id !== personnelToDelete.id));
      
      // Show success toast
      setToast({
        message: `Successfully deleted ${personnelToDelete.name}`,
        type: 'success'
      });
      
      // Close the confirmation dialog
      setPersonnelToDelete(null);
      setIsDeleteConfirmationOpen(false);
      
      // Refresh the data
      const fetchAllPersonnel = async () => {
        try {
          const response = await fetch(`/api/personnel?pageSize=100`);
          if (response.ok) {
            const data = await response.json();
            if (data.success) {
              const personnelData = data.data.personnel.map((person: any) => ({
                ...person,
                id: person._id || person.id,
                lastUpdated: person.lastUpdated ? new Date(person.lastUpdated).toLocaleDateString() : new Date().toLocaleDateString()
              }));
              setAllPersonnel(personnelData);
              setFilteredPersonnel(personnelData);
            }
          }
        } catch (error) {
          console.error('Error refreshing personnel data:', error);
        }
      };
      fetchAllPersonnel();
      
    } catch (error) {
      console.error('Failed to delete personnel:', error);
      setToast({
        message: `Error: ${error instanceof Error ? error.message : 'Failed to delete personnel'}`,
        type: 'error'
      });
    }
  };

  const handleSave = async (updatedData: Partial<Personnel>) => {
    try {
      let response;
      let updatedPersonnel;
      let isNewRecord = false;

      if (selectedPersonnel?.id) {
        // Update existing personnel (future enhancement)
        // For now, update the local state
        updatedPersonnel = { 
          ...selectedPersonnel, 
          ...updatedData, 
          lastUpdated: new Date().toLocaleDateString() 
        };

        setFilteredPersonnel(prev => 
          prev.map(p => p.id === selectedPersonnel.id ? updatedPersonnel : p)
        );
        
        // Set highlight for the updated row
        setRecentlyModified(selectedPersonnel.id.toString());
        
        // Show success toast for update
        setToast({
          message: `Successfully updated ${updatedPersonnel.name}`,
          type: 'success'
        });
      } else {
        isNewRecord = true;
        // Create new personnel
        response = await fetch('/api/personnel', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            ...updatedData,
            // Add any required fields that might be missing
            status: updatedData.status || 'active',
            company: updatedData.company || 'Alpha',
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Failed to create personnel');
        }

        const result = await response.json();
        updatedPersonnel = {
          ...result.data.personnel,
          // Ensure the data has the expected format
          lastUpdated: new Date(result.data.personnel.lastUpdated).toLocaleDateString()
        };

        // Add the new personnel to the state
        setFilteredPersonnel(prev => [...prev, updatedPersonnel]);
        setAllPersonnel(prev => [...prev, updatedPersonnel]);
        
        // Set highlight for the new row
        setRecentlyModified(updatedPersonnel.id.toString());
        
        // Show success toast for creation
        setToast({
          message: `Successfully added ${updatedPersonnel.name}`,
          type: 'success'
        });
      }

      // Close the modal
      setIsModalOpen(false);
      
      // Refresh the data if needed
      if (!selectedPersonnel?.id) {
        // Only refresh when adding new personnel
        const fetchAllPersonnel = async () => {
          try {
            const response = await fetch(`/api/personnel?pageSize=100`);
            if (response.ok) {
              const data = await response.json();
              if (data.success) {
                const personnelData = data.data.personnel.map((person: any) => ({
                  ...person,
                  id: person._id || person.id,
                  lastUpdated: person.lastUpdated ? new Date(person.lastUpdated).toLocaleDateString() : new Date().toLocaleDateString()
                }));
                setAllPersonnel(personnelData);
                setFilteredPersonnel(personnelData);
              }
            }
          } catch (error) {
            console.error('Error refreshing personnel data:', error);
          }
        };
        fetchAllPersonnel();
      }
    } catch (error) {
      console.error('Failed to save personnel:', error);
      setToast({
        message: `Error: ${error instanceof Error ? error.message : 'Failed to save personnel'}`,
        type: 'error'
      });
    }
  };

  // Content for users without permission
  const LimitedAccessContent = () => (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Card>
        <div className="p-6">
          <div className="flex items-center mb-4">
            <div className="bg-indigo-100 rounded-full p-3 mr-4">
              <UserGroupIcon className="h-6 w-6 text-indigo-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Personnel Management</h1>
          </div>
          
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-yellow-800">Limited Access</h3>
                <div className="mt-2 text-sm text-yellow-700">
                  <p>
                    You don't have permission to view personnel records. This feature is available to Staff, Admin, and Director roles.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Personnel Management Features</h2>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start">
                <span className="flex-shrink-0 h-5 w-5 text-gray-400">•</span>
                <span className="ml-2 text-gray-600">View personnel records across your company or the entire organization</span>
              </li>
              <li className="flex items-start">
                <span className="flex-shrink-0 h-5 w-5 text-gray-400">•</span>
                <span className="ml-2 text-gray-600">Add, edit, and manage personnel information</span>
              </li>
              <li className="flex items-start">
                <span className="flex-shrink-0 h-5 w-5 text-gray-400">•</span>
                <span className="ml-2 text-gray-600">Track personnel status, training, and document verification</span>
              </li>
              <li className="flex items-start">
                <span className="flex-shrink-0 h-5 w-5 text-gray-400">•</span>
                <span className="ml-2 text-gray-600">Generate reports and analytics on personnel readiness</span>
              </li>
            </ul>
          </div>
          
          <div className="mt-6">
            <Button
              variant="primary"
              onClick={() => router.push('/dashboard')}
            >
              Return to Dashboard
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );

  // Main content for users with permission
  const PersonnelContent = () => (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 text-white bg-indigo-600 py-2 px-4 rounded-lg shadow-md">Personnel Management</h1>
        <div className="flex flex-col md:flex-row space-y-3 md:space-y-0 md:space-x-3">
          <SearchInput 
            value={searchValue} 
            onChange={handleSearchChange} 
          />
          
          <FilterDropdown 
            value={filterCompany} 
            onChange={(e) => setFilterCompany(e.target.value as CompanyType | 'All')} 
            options={companyOptions}
            label="Filter by company"
          />
          
          <FilterDropdown 
            value={filterStatus} 
            onChange={(e) => setFilterStatus(e.target.value as PersonnelStatus | 'All')} 
            options={statusOptions}
            label="Filter by status"
          />
        </div>
      </div>
      
      {/* Personnel table */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rank
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Company
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Updated
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                    Loading...
                  </td>
                </tr>
              ) : currentPersonnel.length > 0 ? (
                currentPersonnel.map((person) => (
                  <tr 
                    key={person.id}
                    className={recentlyModified === person.id.toString() ? 'animate-highlight' : ''}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{person.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{person.rank}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{person.company}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        person.status === 'ready' 
                          ? 'bg-green-100 text-green-800' 
                          : person.status === 'standby' 
                            ? 'bg-yellow-100 text-yellow-800' 
                            : person.status === 'active'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-gray-100 text-gray-800'
                      }`}>
                        {person.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {person.lastUpdated}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex justify-end space-x-2">
                        <button
                          className="text-indigo-600 hover:text-indigo-900"
                          title="View details"
                          onClick={() => handleView(person)}
                        >
                          <EyeIcon className="h-5 w-5" />
                        </button>
                        {hasPermission('staff') && (
                          <>
                            <button
                              className="text-blue-600 hover:text-blue-900"
                              title="Edit"
                              onClick={() => handleEdit(person)}
                            >
                              <PencilSquareIcon className="h-5 w-5" />
                            </button>
                            {hasPermission('admin') && (
                              <button
                                className="text-red-600 hover:text-red-900"
                                title="Delete"
                                onClick={() => handleDeleteClick(person)}
                              >
                                <TrashIcon className="h-5 w-5" />
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                    No personnel records found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Pagination */}
      <div className="flex justify-between items-center mt-4">
        <div className="text-sm text-gray-700">
          Showing <span className="font-medium">{currentPersonnel.length}</span> of{' '}
          <span className="font-medium">{filteredPersonnel.length}</span> personnel
        </div>
        <div className="flex space-x-2">
          <button
            className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={currentPage === 1}
          >
            Previous
          </button>
          <button
            className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            disabled={currentPage === totalPages}
          >
            Next
          </button>
        </div>
      </div>

      {/* Add Personnel button (only for Staff and above) */}
      {hasPermission('staff') && (
        <div className="mt-6">
          <Button
            variant="primary"
            onClick={() => {
              // Reset the selected personnel to null for creating a new record
              setSelectedPersonnel(null);
              setModalMode('edit');
              setIsModalOpen(true);
              
              // Small delay to ensure state is updated before modal opens
              setTimeout(() => {
                console.log("Opening modal for new personnel");
              }, 100);
            }}
            className="flex items-center relative animate-pulse-success"
          >
            <div className="absolute inset-0 rounded-md bg-green-400 opacity-30 blur-sm"></div>
            <UserPlusIcon className="h-5 w-5 mr-2" />
            Add Personnel
          </Button>
        </div>
      )}

      {/* Personnel Modal */}
      <PersonnelModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        personnel={selectedPersonnel}
        mode={modalMode}
        onSave={handleSave}
      />

      <ConfirmationDialog
        isOpen={isDeleteConfirmationOpen}
        onClose={() => setIsDeleteConfirmationOpen(false)}
        onConfirm={handleDelete}
        title="Delete Personnel Record"
        message={`Are you sure you want to delete the record for ${personnelToDelete?.name}? This action cannot be undone.`}
        confirmText="Delete"
        cancelText="Cancel"
        type="danger"
      />
    </div>
  );

  // Main render
  return (
    <div className="min-h-screen bg-gray-100 pb-10">
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
        </div>
      ) : (
        // Always show the PersonnelContent for now
        <PersonnelContent />
      )}

      {/* Personnel modal */}
      {isModalOpen && selectedPersonnel && (
        <PersonnelModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          personnel={selectedPersonnel}
          mode={modalMode}
          onSave={handleSave}
        />
      )}

      {/* Delete confirmation */}
      <ConfirmationDialog
        isOpen={isDeleteConfirmationOpen}
        onClose={() => setIsDeleteConfirmationOpen(false)}
        onConfirm={handleDelete}
        title="Delete Personnel Record"
        message={`Are you sure you want to delete the record for ${personnelToDelete?.name}? This action cannot be undone.`}
        confirmText="Delete"
        cancelText="Cancel"
        type="danger"
      />
      
      {/* Toast notification */}
      {toast && (
        <Toast 
          message={toast.message} 
          type={toast.type} 
          onClose={() => setToast(null)} 
        />
      )}
    </div>
  );
}
