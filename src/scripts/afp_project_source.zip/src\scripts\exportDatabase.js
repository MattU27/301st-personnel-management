// Export MongoDB database to JSON files
// Run with: node src/scripts/exportDatabase.js

const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

// MongoDB connection URI - check for all possible environment variable names
const MONGODB_URI = process.env.MONGODB_URI || process.env.DB_URI || process.env.DATABASE_URL || "mongodb://localhost:27017/afp";

// Output directory
const OUTPUT_DIR = path.join(__dirname, '../../db_backup');

console.log('Starting database export...');
console.log(`Attempting to connect to: ${MONGODB_URI}`);

// Create output directory if it doesn't exist
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  console.log(`Created output directory: ${OUTPUT_DIR}`);
}

// Connect to the database
mongoose.connect(MONGODB_URI)
  .then(async () => {
    console.log('Connected to MongoDB successfully');
    console.log(`Database name: ${mongoose.connection.db.databaseName}`);
    
    try {
      // Get all collections in the database
      const collections = await mongoose.connection.db.listCollections().toArray();
      console.log(`Found ${collections.length} collections`);
      
      if (collections.length === 0) {
        console.log('No collections found. This could mean:');
        console.log('1. The database exists but is empty');
        console.log('2. You might be connecting to the wrong database');
        console.log('3. The connection string might be incorrect');
        console.log('\nPlease check your .env file for the correct MONGODB_URI value');
        
        // List all databases to help troubleshoot
        const dbs = await mongoose.connection.db.admin().listDatabases();
        console.log('\nAvailable databases:');
        dbs.databases.forEach(db => {
          console.log(`- ${db.name}`);
        });
        
        return;
      }
      
      // Export each collection
      for (const collection of collections) {
        const collectionName = collection.name;
        console.log(`Exporting collection: ${collectionName}`);
        
        // Get all documents in the collection
        const documents = await mongoose.connection.db.collection(collectionName).find({}).toArray();
        
        // Save to JSON file
        const outputPath = path.join(OUTPUT_DIR, `${collectionName}.json`);
        fs.writeFileSync(outputPath, JSON.stringify(documents, null, 2));
        
        console.log(`- Exported ${documents.length} documents to ${outputPath}`);
      }
      
      console.log('\nExport completed successfully!');
      console.log(`All data exported to: ${OUTPUT_DIR}`);
      console.log('You can now copy the db_backup folder to your laptop.');
    } catch (error) {
      console.error('Error exporting data:', error);
    } finally {
      // Close the connection
      await mongoose.connection.close();
      console.log('Database connection closed');
    }
  })
  .catch(error => {
    console.error('Failed to connect to MongoDB:', error);
    console.log('\nTroubleshooting tips:');
    console.log('1. Check if MongoDB is running');
    console.log('2. Verify your connection string in the .env file');
    console.log('3. Make sure you have the correct database name');
    console.log('4. Check if your IP is allowed to connect to the database');
  }); 