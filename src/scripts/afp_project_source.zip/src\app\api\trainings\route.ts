import { NextResponse } from 'next/server';
import { dbConnect } from '@/utils/dbConnect';
import Training, { TrainingStatus } from '@/models/Training';
import { verifyJWT } from '@/utils/auth';
import mongoose from 'mongoose';

/**
 * GET handler to retrieve trainings
 */
export async function GET(request: Request) {
  try {
    // Connect to MongoDB
    await dbConnect();
    
    // Get query parameters
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const userId = searchParams.get('userId');
    const trainingId = searchParams.get('trainingId');
    
    // Verify authentication
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const token = authHeader.split(' ')[1];
    const decoded = await verifyJWT(token);
    
    if (!decoded) {
      return NextResponse.json(
        { success: false, error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    // Build query
    const query: any = {};
    
    // If trainingId is provided, fetch a specific training
    if (trainingId) {
      query._id = new mongoose.Types.ObjectId(trainingId);
    }
    
    // Filter by status if provided
    if (status && Object.values(TrainingStatus).includes(status as TrainingStatus)) {
      query.status = status;
    }
    
    // If userId is provided, filter by attendees
    if (userId) {
      query['attendees.userId'] = new mongoose.Types.ObjectId(userId);
    }
    
    // Execute query and populate attendee user data
    const trainings = await Training.find(query)
      .populate({
        path: 'attendees.userId',
        select: 'firstName lastName rank company email serviceNumber', 
        model: 'User'
      })
      .sort({ startDate: 1 })
      .lean();
    
    // Process trainings to add registration status and format attendee data
    const processedTrainings = trainings.map(training => {
      const userAttendee = training.attendees?.find(
        (attendee: { userId: mongoose.Types.ObjectId | string | any }) => 
          attendee.userId && attendee.userId._id && 
          attendee.userId._id.toString() === decoded.userId
      );
      
      // Format attendees to include user data in a more accessible format
      const formattedAttendees = training.attendees?.map((attendee: any) => {
        if (attendee.userId && typeof attendee.userId === 'object') {
          return {
            ...attendee,
            userData: {
              firstName: attendee.userId.firstName,
              lastName: attendee.userId.lastName,
              rank: attendee.userId.rank,
              company: attendee.userId.company,
              email: attendee.userId.email,
              serviceNumber: attendee.userId.serviceNumber
            },
            userId: attendee.userId._id
          };
        }
        return attendee;
      });
      
      return {
        ...training,
        attendees: formattedAttendees || [],
        registrationStatus: userAttendee ? userAttendee.status : 'not_registered'
      };
    });
    
    return NextResponse.json({
      success: true,
      data: {
        trainings: processedTrainings
      }
    });
  } catch (error: any) {
    console.error('Error fetching trainings:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Error fetching trainings' },
      { status: 500 }
    );
  }
}

/**
 * POST handler to register for a training
 */
export async function POST(request: Request) {
  try {
    // Connect to MongoDB
    await dbConnect();
    
    // Verify authentication
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const token = authHeader.split(' ')[1];
    const decoded = await verifyJWT(token);
    
    if (!decoded) {
      return NextResponse.json(
        { success: false, error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    // Get data from request body
    const data = await request.json();
    const { trainingId, action } = data;
    
    if (!trainingId) {
      return NextResponse.json(
        { success: false, error: 'Training ID is required' },
        { status: 400 }
      );
    }
    
    if (!action || !['register', 'cancel'].includes(action)) {
      return NextResponse.json(
        { success: false, error: 'Valid action (register or cancel) is required' },
        { status: 400 }
      );
    }
    
    // Find the training
    const training = await Training.findById(trainingId);
    
    if (!training) {
      return NextResponse.json(
        { success: false, error: 'Training not found' },
        { status: 404 }
      );
    }
    
    // Check if training is upcoming or ongoing
    if (training.status === TrainingStatus.COMPLETED || training.status === TrainingStatus.CANCELLED) {
      return NextResponse.json(
        { success: false, error: 'Cannot register for completed or cancelled trainings' },
        { status: 400 }
      );
    }
    
    const userId = new mongoose.Types.ObjectId(decoded.userId);
    
    // Check if user is already registered
    const attendeeIndex = training.attendees?.findIndex(
      (attendee: { userId: mongoose.Types.ObjectId | string }) => 
        attendee.userId.toString() === decoded.userId
    );
    
    if (action === 'register') {
      // Check capacity
      if (training.capacity && training.attendees && training.attendees.length >= training.capacity) {
        return NextResponse.json(
          { success: false, error: 'Training has reached maximum capacity' },
          { status: 400 }
        );
      }
      
      // Register user
      if (attendeeIndex !== undefined && attendeeIndex >= 0) {
        // User is already registered, update their status
        training.attendees[attendeeIndex].status = 'registered';
      } else {
        // Add user to attendees
        if (!training.attendees) {
          training.attendees = [];
        }
        
        training.attendees.push({
          userId,
          status: 'registered',
          registrationDate: new Date()
        });
      }
    } else if (action === 'cancel') {
      // Cancel registration
      if (attendeeIndex !== undefined && attendeeIndex >= 0) {
        // Remove from attendees array
        training.attendees.splice(attendeeIndex, 1);
      } else {
        return NextResponse.json(
          { success: false, error: 'User is not registered for this training' },
          { status: 400 }
        );
      }
    }
    
    // Save the updated training
    await training.save();
    
    // Return the updated training
    return NextResponse.json({
      success: true,
      data: {
        training: {
          ...training.toObject(),
          registrationStatus: action === 'register' ? 'registered' : 'not_registered'
        }
      }
    });
  } catch (error: any) {
    console.error('Error updating training registration:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Error updating training registration' },
      { status: 500 }
    );
  }
} 