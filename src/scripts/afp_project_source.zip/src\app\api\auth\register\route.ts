import { NextResponse } from 'next/server';
import { dbConnect } from '@/utils/dbConnect';
import User from '@/models/User';
import bcrypt from 'bcryptjs';

export async function POST(request: Request) {
  try {
    // Connect to MongoDB
    await dbConnect();
    
    // Get registration data from request body
    const data = await request.json();
    
    // Validate required fields
    const requiredFields = ['firstName', 'lastName', 'email', 'password', 'role', 'militaryId'];
    for (const field of requiredFields) {
      if (!data[field]) {
        return NextResponse.json(
          { success: false, error: `${field} is required` },
          { status: 400 }
        );
      }
    }
    
    // Check if email already exists
    const existingUser = await User.findOne({ email: data.email });
    if (existingUser) {
      return NextResponse.json(
        { success: false, error: 'Email already registered' },
        { status: 400 }
      );
    }
    
    // Validate role
    const validRoles = ['staff', 'admin', 'director'];
    if (!validRoles.includes(data.role)) {
      return NextResponse.json(
        { success: false, error: 'Invalid role' },
        { status: 400 }
      );
    }
    
    // Check if rank is provided for reservist and enlisted roles
    if (['reservist', 'enlisted'].includes(data.role) && !data.rank) {
      return NextResponse.json(
        { success: false, error: 'Rank is required for reservist and enlisted roles' },
        { status: 400 }
      );
    }
    
    // Create new user
    const user = new User({
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email.toLowerCase(),
      password: data.password, // Will be hashed by the pre-save hook in the User model
      role: data.role,
      company: data.company,
      rank: data.rank || undefined,
      militaryId: data.militaryId,
      status: 'pending', // All registrations start as pending until approved
      specializations: data.specializations || [],
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    
    // Save user to database
    await user.save();
    
    // Return success response
    return NextResponse.json({
      success: true,
      message: 'Registration successful',
      data: {
        email: user.email,
        role: user.role,
        status: user.status,
      },
    });
  } catch (error: any) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Registration failed' },
      { status: 500 }
    );
  }
} 