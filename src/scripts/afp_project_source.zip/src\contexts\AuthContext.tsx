"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { UserRole, PersonnelStatus, CompanyType } from '@/types/personnel';
import axios from 'axios';
import Cookies from 'js-cookie';

// Cookie helper functions
const setCookie = (name: string, value: string, days = 7) => {
  const expires = new Date(Date.now() + days * 864e5).toUTCString();
  document.cookie = name + '=' + encodeURIComponent(value) + '; expires=' + expires + '; path=/';
};

const getCookie = (name: string) => {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return decodeURIComponent(parts.pop()?.split(';').shift() || '');
  return null;
};

// Define user interface
interface User {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: UserRole;
  company?: CompanyType;
  rank?: string;
  status?: PersonnelStatus;
  profileImage?: string;
}

// Add a more comprehensive permission system
interface Permission {
  id: string;
  name: string;
  description: string;
}

// Define permissions by role
const ROLE_PERMISSIONS: Record<UserRole, string[]> = {
  'reservist': [
    'view_own_profile',
    'edit_own_profile',
    'view_own_documents',
    'upload_own_documents',
    'view_trainings',
    'register_trainings',
    'view_announcements',
    'view_calendar',
    'view_attended_trainings',
    'view_policy'
  ],
  'enlisted': [
    'view_own_profile',
    'edit_own_profile',
    'view_own_documents',
    'upload_own_documents',
    'view_trainings',
    'register_trainings',
    'view_announcements',
    'view_calendar',
    'view_attended_trainings',
    'view_policy'
  ],
  'staff': [
    'view_own_profile',
    'edit_own_profile',
    'view_own_documents',
    'upload_own_documents',
    'view_trainings',
    'register_trainings',
    'view_announcements',
    'manage_company_personnel',
    'add_personnel_records',
    'update_personnel_records',
    'view_company_personnel',
    'update_reservist_status',
    'approve_reservist_accounts',
    'post_announcements',
    'manage_trainings',
    'validate_documents',
    'upload_policy',
    'manage_policy'
  ],
  'admin': [
    'view_own_profile',
    'edit_own_profile',
    'view_own_documents',
    'upload_own_documents',
    'view_trainings',
    'register_trainings',
    'view_announcements',
    'manage_staff_accounts',
    'deactivate_staff_accounts',
    'add_personnel_records',
    'update_personnel_records',
    'delete_personnel_records',
    'view_all_personnel',
    'approve_reservist_accounts',
    'deactivate_reservist_accounts',
    'manage_system',
    'manage_policy'
  ],
  'director': [
    'view_own_profile',
    'edit_own_profile',
    'view_own_documents',
    'upload_own_documents',
    'view_trainings',
    'register_trainings',
    'view_announcements',
    'create_admin_accounts',
    'review_admin_registrations',
    'approve_admin_accounts',
    'reject_admin_accounts',
    'deactivate_admin_accounts',
    'reactivate_admin_accounts',
    'manage_admin_roles',
    'view_system_analytics',
    'view_prescriptive_analytics',
    'manage_system_configuration',
    'view_reports',
    'manage_reports',
    'export_reports',
    'manage_resources',
    'manage_trainings_schedule'
  ]
};

// Add RegisterData interface
interface RegisterData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  role?: string;
  rank?: string;
  company?: string;
}

// Define auth context interface
export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean | null;
  isLoading: boolean;
  mounted: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  hasPermission: (requiredRole: UserRole) => boolean;
  hasSpecificPermission: (permission: string) => boolean;
  sessionExpiring: boolean;
  extendSession: () => void;
  simulateRole: (role: UserRole) => void;
  isRedirecting: boolean;
  register: (userData: RegisterData) => Promise<void>;
  getToken: () => Promise<string | null>;
}

// Create the auth context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Session timeout in milliseconds (30 minutes)
const SESSION_TIMEOUT = 30 * 60 * 1000;

// Auth provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [mounted, setMounted] = useState(false);
  const router = useRouter();
  const [sessionExpiring, setSessionExpiring] = useState(false);
  const sessionTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const sessionWarningRef = useRef<NodeJS.Timeout | null>(null);
  const [simulatedRole, setSimulatedRole] = useState<UserRole | null>(null);
  const [isRedirecting, setIsRedirecting] = useState(false);

  // Handle client-side mounting
  useEffect(() => {
    console.log('AuthProvider mounted');
    setMounted(true);
  }, []);

  // Check for existing session
  useEffect(() => {
    if (mounted) {
      console.log('Checking auth state...');
      checkAuth();
    }
  }, [mounted]);

  // Log the current auth context state
  useEffect(() => {
    console.log('AuthContext state:', { user, isLoading, isAuthenticated: !!user, mounted });
  }, [user, isLoading, mounted]);

  const checkAuth = async () => {
    console.log('Running checkAuth...');
    try {
      // Check for token in localStorage and cookies
      const token = localStorage.getItem('token') || getCookie('token');
      console.log('Token found:', token ? 'exists' : 'not found');
      
      if (!token) {
        setUser(null);
        setIsLoading(false);
        return;
      }

      // Set/sync cookie with localStorage if token exists
      if (token && !getCookie('token')) {
        document.cookie = `token=${token}; path=/; max-age=${60 * 60 * 24}; SameSite=Strict`;
      }
      
      // Set/sync localStorage with cookie if needed
      if (token && !localStorage.getItem('token')) {
        localStorage.setItem('token', token);
      }

      // Verify token with backend
      try {
        const response = await axios.get('/api/auth/me', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        if (response.data.success) {
          setUser(response.data.data.user);
          startSessionTimer();
        } else {
          // Invalid token
          setUser(null);
          localStorage.removeItem('token');
          document.cookie = 'token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT';
        }
      } catch (error) {
        console.error('Token verification failed:', error);
        setUser(null);
        localStorage.removeItem('token');
        document.cookie = 'token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT';
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Reset session timeout
  const resetSessionTimeout = useCallback(() => {
    // Clear existing timeouts
    if (sessionTimeoutRef.current) {
      clearTimeout(sessionTimeoutRef.current);
      sessionTimeoutRef.current = null;
    }

    if (sessionWarningRef.current) {
      clearTimeout(sessionWarningRef.current);
      sessionWarningRef.current = null;
    }

    // Set new timeouts
    if (user) {
      sessionWarningRef.current = setTimeout(() => {
        setSessionExpiring(true);
      }, SESSION_TIMEOUT - 2 * 60 * 1000); // 2 minutes before timeout

      sessionTimeoutRef.current = setTimeout(() => {
        logout();
      }, SESSION_TIMEOUT);
    }
  }, [user]);

  // Start session timer
  const startSessionTimer = useCallback(() => {
    resetSessionTimeout();

    // Add activity listeners
    const activityEvents = ['mousedown', 'keydown', 'touchstart', 'click'];
    
    const activityHandler = () => {
      if (user) {
        resetSessionTimeout();
        if (sessionExpiring) {
          setSessionExpiring(false);
        }
      }
    };

    activityEvents.forEach(event => {
      window.addEventListener(event, activityHandler);
    });

    return () => {
      activityEvents.forEach(event => {
        window.removeEventListener(event, activityHandler);
      });
      
      if (sessionTimeoutRef.current) {
        clearTimeout(sessionTimeoutRef.current);
      }
      
      if (sessionWarningRef.current) {
        clearTimeout(sessionWarningRef.current);
      }
    };
  }, [user, resetSessionTimeout, sessionExpiring]);

  // Setup session timeout when user changes
  useEffect(() => {
    const cleanupFunction = startSessionTimer();
    return cleanupFunction;
  }, [user, startSessionTimer]);

  // Extend session
  const extendSession = useCallback(() => {
    if (sessionExpiring) {
      setSessionExpiring(false);
      resetSessionTimeout();
    }
  }, [sessionExpiring, resetSessionTimeout]);

  // Login function
  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const response = await axios.post('/api/auth/login', { email, password });
      
      if (response.data.success) {
        const { token, user } = response.data.data;
        
        // Save token to localStorage
        localStorage.setItem('token', token);
        
        // Also set the token in a cookie for middleware
        document.cookie = `token=${token}; path=/; max-age=${60 * 60 * 24}; SameSite=Strict`;
        
        // Set user state
        setUser(user);
        
        // Start session timer
        resetSessionTimeout();
        
        // Prevent double redirection
        setIsRedirecting(true);
        
        // Use direct window.location for more reliable redirect
        window.location.href = '/dashboard';
        return;
      } else {
        throw new Error(response.data.error || 'Login failed');
      }
    } catch (error: any) {
      console.error('Login error:', error);
      throw new Error(error.response?.data?.error || error.message || 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = async () => {
    setIsLoading(true);
    try {
      // Clear token from localStorage
      localStorage.removeItem('token');
      
      // Clear token from cookies
      document.cookie = 'token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT';
      
      // Clear user state
      setUser(null);
      
      // Clear timeouts
      if (sessionTimeoutRef.current) {
        clearTimeout(sessionTimeoutRef.current);
        sessionTimeoutRef.current = null;
      }
      
      if (sessionWarningRef.current) {
        clearTimeout(sessionWarningRef.current);
        sessionWarningRef.current = null;
      }
      
      setSessionExpiring(false);
      
      // Redirect to login page
      window.location.href = '/login';
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Check if user has required role or higher
  const hasPermission = (requiredRole: UserRole): boolean => {
    if (!user) return false;
    
    // Use simulated role if set
    const roleToCheck = simulatedRole || user.role;
    
    const roleHierarchy: Record<UserRole, number> = {
      'reservist': 1,
      'enlisted': 1,
      'staff': 2,
      'admin': 3,
      'director': 4
    };
    
    return roleHierarchy[roleToCheck] >= roleHierarchy[requiredRole];
  };

  // Simulate a role for testing purposes
  const simulateRole = (role: UserRole) => {
    setSimulatedRole(role);
  };

  // Check if user has a specific permission
  const hasSpecificPermission = (permission: string): boolean => {
    if (!user) return false;
    
    // Admin and director roles have access to all permissions
    if (user.role === 'admin' || user.role === 'director') {
      return true;
    }
    
    // For other roles, check the specific permission
    const roleToCheck = user.role as UserRole;
    return ROLE_PERMISSIONS[roleToCheck]?.includes(permission) || false;
  };

  const getToken = async (): Promise<string | null> => {
    try {
      const storedToken = Cookies.get('token');
      if (!storedToken) return null;
      return storedToken;
    } catch (error) {
      console.error('Error getting token:', error);
      return null;
    }
  };

  // Add register function
  const register = async (userData: RegisterData): Promise<void> => {
    try {
      // This is a stub implementation
      console.log('Register function called with:', userData);
      // In a real implementation, you would make an API call to register the user
    } catch (error) {
      console.error('Registration failed:', error);
      throw error;
    }
  };

  // Provide auth context value
  const contextValue: AuthContextType = {
    user,
    isLoading,
    isAuthenticated: !!user,
    mounted,
    login,
    logout,
    hasPermission,
    hasSpecificPermission,
    sessionExpiring,
    extendSession,
    simulateRole,
    isRedirecting,
    getToken,
    register,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook to use auth context
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
} 