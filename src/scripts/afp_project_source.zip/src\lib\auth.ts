import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

interface DecodedToken {
  id: string;
  email: string;
  role: string;
  permissions?: string[];
  iat?: number;
  exp?: number;
}

export async function verifyAuthToken(token: string): Promise<DecodedToken | null> {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as DecodedToken;
    return decoded;
  } catch (error) {
    console.error('Error verifying token:', error);
    return null;
  }
}

export function generateAuthToken(userData: { id: string; email: string; role: string; permissions?: string[] }): string {
  const { id, email, role, permissions } = userData;
  
  return jwt.sign(
    { id, email, role, permissions },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
} 