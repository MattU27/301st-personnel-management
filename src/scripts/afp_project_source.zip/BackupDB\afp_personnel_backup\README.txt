AFP PERSONNEL DATABASE BACKUP
===============================
Created: 4/4/2025, 3:47:50 AM

This folder contains a backup of your AFP Personnel Management System database.
Each JSON file represents a collection from your MongoDB database.

To import this data into another MongoDB instance:
1. Install MongoDB Database Tools (https://www.mongodb.com/try/download/database-tools)
2. Use the 'mongoimport' tool for each file:
   mongoimport --db afp_personnel_db --collection [COLLECTION_NAME] --file [FILENAME] --jsonArray

For example:
   mongoimport --db afp_personnel_db --collection users --file users.json --jsonArray

Note: Replace [COLLECTION_NAME] with the name of the collection (e.g., users, documents, trainings)
      Replace [FILENAME] with the corresponding JSON file path.
